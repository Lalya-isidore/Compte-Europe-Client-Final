<?php


    deconnexion();
?>
